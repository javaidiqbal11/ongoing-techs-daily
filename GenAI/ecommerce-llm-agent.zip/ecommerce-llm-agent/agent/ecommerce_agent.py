from langchain.agents import initialize_agent
from langchain.chat_models import ChatOpenAI
from modules.tools import product_tool, faq_tool
import os

os.environ["OPENAI_API_KEY"] = "API Key" # Replace with your own key 
llm = ChatOpenAI(temperature=0)

agent = initialize_agent(
    tools=[product_tool, faq_tool],
    llm=llm,
    agent="zero-shot-react-description",
    verbose=True
)

def run_agent(query):
    return agent.run(query)