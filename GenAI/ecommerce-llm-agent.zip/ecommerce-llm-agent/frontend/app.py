import gradio as gr
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from agent.ecommerce_agent import run_agent


def handle_query(user_input):
    return run_agent(user_input)

gr.Interface(fn=handle_query, inputs="text", outputs="text", title="E-Commerce AI Agent").launch()
