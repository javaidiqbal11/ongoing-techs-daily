from langchain.agents import Tool
from modules.product_retrieval import filter_products
from modules.faq_handler import get_best_faq_match

product_tool = Tool(
    name="ProductFilter",
    func=lambda q: str(filter_products(q)),
    description="Use this to retrieve products based on filters like category, price, rating, and stock."
)

faq_tool = Tool(
    name="FAQRetriever",
    func=get_best_faq_match,
    description="Use this to answer FAQs based on customer queries."
)