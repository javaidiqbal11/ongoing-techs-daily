from sentence_transformers import SentenceTransformer, util
import pandas as pd

model = SentenceTransformer("all-MiniLM-L6-v2")

def get_best_faq_match(query, faq_path='data/FAQ.csv'):
    df = pd.read_csv(faq_path)
    questions = df['Question'].tolist()
    embeddings = model.encode(questions, convert_to_tensor=True)
    query_embedding = model.encode(query, convert_to_tensor=True)

    similarity = util.pytorch_cos_sim(query_embedding, embeddings)
    best_idx = similarity.argmax().item()

    return df.iloc[best_idx]['Answer']