import pandas as pd
import re

def parse_query(query):
    filters = {}
    
    # Extract category
    match = re.search(r'(electronics|clothing|furniture|toys|appliances)', query, re.IGNORECASE)
    if match:
        filters['Category'] = match.group(1).capitalize()

    # Price range
    match = re.search(r'under \$?(\d+)', query)
    if match:
        filters['PriceMax'] = float(match.group(1))

    # Rating
    if 'top-rated' in query or 'high rating' in query:
        filters['RatingMin'] = 4.0

    # Stock
    if 'in stock' in query:
        filters['InStock'] = True

    return filters

def filter_products(query, df_path='data/Product_Statistics.csv'):
    df = pd.read_csv(df_path)
    filters = parse_query(query)

    if 'Category' in filters:
        df = df[df['Category'].str.lower() == filters['Category'].lower()]
    if 'PriceMax' in filters:
        df = df[df['Price'] <= filters['PriceMax']]
    if 'RatingMin' in filters:
        df = df[df['Rating'] >= filters['RatingMin']]
    if 'InStock' in filters:
        df = df[df['Stock Level'] > 0]

    return df.sort_values(by='Rating', ascending=False).head(5).to_dict(orient='records')
