# E-Commerce LLM Agent

## Features
- Filter products by natural language (e.g., "top-rated electronics under $500 in stock").
- Answer customer FAQs using vector similarity.
- Powered by LangChain + OpenAI + Sentence Transformers.

## Setup
```bash
pip install -r requirements.txt
export OPENAI_API_KEY=your-key
python frontend/app.py
```

## Sample Queries
- "Show me electronics under $500 with high rating."
- "What is the return policy?"

## Folder Structure
- `modules/`: Data logic and tool setup
- `agent/`: LLM-based agent orchestration
- `frontend/`: Streamlit or Gradio UI
- `data/`: Sample CSVs